const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const userRoutes = require('./routes/userRouts');
const taskRoutes = require('./routes/taskRouts')

require('dotenv').config();
require('./db');
const PORT = 3307;

app.use(bodyParser.json());
app.use('/users', userRoutes);
app.use('/tasks', taskRoutes);


app.get('/',(req,res) =>{ 
    res.json({
        message: 'task manager api is working'
    })
})
app.listen(3307, ()=> {
    console.log('server is running on port 3307');
})